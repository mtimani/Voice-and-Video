
// fonction de quantification
short int quantif( double val, int iband );
// fonction de dequantification
double dequantif( short int val, int iband );
// fonction de preparation des tables de dequantification
void prep_dequant();
// production d'un fichier javascript pour graphiques 
int plot_js( int iband );
