API de kit_01.c (extrait du code de reference ISO-MPEG)

====== fonctions d'encodage (filtrage en 32 sous-bandes)

void window_subband( short *buffer, double *z, int k );

- cette fonction prend 32 echantillons de 16 bits dans buffer[]
- elle les introduit dans un buffer circulaire interne de 512 echantillons (par canal)
- elle applique un fenetrage (de Hanning) sur ces 512 echantillons
- elle restitue le resultat dans z (valeurs normalisees sur l'intervalle (-1.0, +1.0) )
On doit lui indiquer le canal k (0 ou 1) a cause du buffer interne.

void filter_subband( double *z, double *s );

- cette fonction prend 512 echantillons resultant du fenetrage dans z
- elle restitue 32 echantillons (chip) a raison de 1 par sous-bande


====== fonction de decodage (reconstitution du signal a partir des 32 sous-bandes)

int SubBandSynthesis ( double * bandPtr, int channel, short * samples );

- cette fonction prend 32 echantillons normalises dans bandPtr[]
  a raison de 1 par sous-bande
- elle restitue 32 echantilons de 16 bits dans samples[]
- on doit lui indiquer le canal (0 ou 1) dans channel a cause du buffer interne.
