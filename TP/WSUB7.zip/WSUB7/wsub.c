/* programme pour experimenter le decoupage en bandes sur fichier WAVE */
/*   */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <math.h>

#include "kit_01w.h"
#include "wav_head.h"

/* fonction de lecture des coefficients de quantification
   fichier quant.txt --> tableau equ (64 valeurs max)
	- si le fichier contient moins de 33 valeurs, canal droit = copie du canal gauche
	- si le fichier contient moins de 32 valeurs, le tableau sera compl�t� par des z�ros
 */
static void initquant( double * equ )
{
char * enam = "quant.txt"; 
int i; FILE *efil; char lbuf[82];
	   
efil = fopen( enam, "r" );
if	( efil == NULL )
	{ printf("manque fichier de coefficients %s\n", enam ); exit(1);  }
for	( i = 0; i < 64; i++ )
	equ[i] = 0.0; /* zero par defaut */

i = 0;
while	( fgets( lbuf, 80, efil ) != NULL )
	{   
	sscanf( lbuf, "%lf", &equ[i] );
	i++; if ( i >= 64 ) break;
	}
if	( i <= 32 )
        for	( i = 0; i < 32; i++ )
		equ[i+32] = equ[i];     /* copier canal0 sur canal 1 */
             
printf("coefficients de quantification canal 0 :\n");
for	( i = 0; i < 32; i++ )
	{
	printf("%8g ", equ[i] );
	if ( (i & 7) == 7 ) printf("\n");
	}     
printf("coefficients de quantification canal 1 :\n");
for	( i = 32; i < 64; i++ )
	{
	printf("%8g ", equ[i] );
	if ( (i & 7) == 7 ) printf("\n");
	}
}

/* fonction de quantification generique d'une valeur */
static double quantif( double x, double q )
{
double qx; int ix;
if  ( q == 0.0 ) return( x );

if   ( x >= 0.0 )
     {
     qx = ( x / q ) + 0.5;
     ix = (int)floor(qx);
     qx = q * ix;
     return ( qx );
     }	     
else {
     qx = ( -x / q ) + 0.5;
     ix = (int)floor(qx);
     qx = q * ix;
     return ( -qx );
     }
}


/* fonction de quantification experimentale des echantillons de sous-bandes

Cette fonction est appelee pour chaque chip de 32 samples audio.
on lui passe :
  sbl   : buffer de 32 doubles (1 pour chaque sous bande) canal gauche
  sbl   : buffer de 32 doubles (1 pour chaque sous bande) canal droit
  kqu	: tableau de coefficients de quantification
	  de 0 a 31 = canal gauche, de 32 a 63 = canal droit 
*/
static void sbprocess( double *sbl, double *sbr, double *kqu )
{
int isam;
for ( isam = 0; isam < 32; isam++ )
    {
    sbl[isam] = quantif( sbl[isam], kqu[isam] );
    sbr[isam] = quantif( sbr[isam], kqu[isam+32] );
    }
}


/* fonction de mise a jour des statistiques par sous-bandes

Cette fonction est appelee pour chaque chip de 32 samples audio.
on lui passe :
  sbl   : buffer de 32 doubles (1 pour chaque sous bande) canal gauche
  sbl   : buffer de 32 doubles (1 pour chaque sous bande) canal droit
*/
static void sbstats( double *sbl, double *sbr, double stats[32][5] )
{
int isam;
double absl, absr;
	
for ( isam = 0; isam < 32; isam++ )
    {
    absl = fabs(sbl[isam]);
    absr = fabs(sbr[isam]);
    stats[isam][0] += absl; 
    stats[isam][1] += absr;
    if	( absl > stats[isam][2] ) stats[isam][2] = absl;
    if	( absr > stats[isam][3] ) stats[isam][3] = absr;
    stats[isam][4] += 1.0;
    }
}

// valeurs pour option :
#define QUANT_1	 0
#define QUANT_32 1
#define STATS	 3

/* fonction pour filtrer les donnees WAVE et eventuellement les sauver */
/* le traitement des headers est suppose deja fait */
/* traitement par trames de NCHIPS chips
   1 chip = 32 samples audio = 1 sample par sous-bande */
static void process_wav( wavpars *s, wavpars *d, int option, double quantum_global )
{
// buffers pour acces aux fichiers, FRAMLEN doit etre multiple de 128 bytes = 1 chip
#define NCHIPS 64
#define FRAMLEN 128*NCHIPS
unsigned char sbuf[FRAMLEN];	// source

int bpsam, qbytes, rdcont, sbufcont, wrcont;	// comptage de bytes
int sind, ibase;		// index de bytes
int ibloc=0;

// buffers pour le traitement des echantillons
short int sl[32];		// donnees WAV 16 bits
short int sr[32];		// donnees WAV 16 bits
static double zbuf[512];	// buffer pour filtre polyphase
double sbl[32];			// echantillons filtres par sous bandes
double sbr[32];			// echantillons filtres par sous bandes
int ichip;			// index de chip
int isam;			// index d'echantillon

double kqu[32];			// coeffs de quantification par bande
double stats[32][5];		// statistiques par bande
int qchip;

memset( (void *)stats, 0, sizeof(stats) );

bpsam = s->chan * ((s->resol)>>3);
qbytes = s->wavsize * bpsam;

// preparation de la quantification
if	( option == QUANT_1 )
	quantum_global *= 32767.0;
else if	( option == QUANT_32 )
	initquant( kqu );	

while	( qbytes > 0L )   /* qbytes = nombre de bytes restant a traiter */
	{
	if	( qbytes < FRAMLEN )
		rdcont = qbytes;
	else	rdcont = FRAMLEN;
	sbufcont = read( s->hand, sbuf, rdcont );
	if	( sbufcont < rdcont )
		gasp("fin inattendue fichier source");
   
	if	( rdcont < FRAMLEN ) /* completer avec des zeros */
	for	( sind = rdcont; sind < FRAMLEN; sind++ )
		sbuf[sind] = 0;
	/* boucle des chips de 32 samples soit 128 bytes ( source 16 bits stereo only )*/
	for	( ichip = 0; ichip < (FRAMLEN/128); ichip++ )
		{
			/* lire les echantillons audio */
		ibase = ichip * 128;
		for	( isam = 0; isam < 32; isam++ )
			{
			sind = ibase + ( 4 * isam );	   
			sl[isam] = ( sbuf[sind+1] << 8 ) + sbuf[sind];
			sr[isam] = ( sbuf[sind+3] << 8 ) + sbuf[sind+2];
			}
		switch	( option )
			{
			case QUANT_1 :	//  quantification globale, sans filtrage
				for	( isam = 0; isam < 32; isam++ )
					{
					sl[isam] = (short)quantif( (double)sl[isam], quantum_global );
					sr[isam] = (short)quantif( (double)sr[isam], quantum_global );
					}
				/* ecrire les echantillons audio dans le buffer de trame */
				ibase = ichip * 128;
				for	( isam = 0; isam < 32; isam++ )
					{
					sind = ibase + ( 4 * isam );	   
					sbuf[sind]   =   sl[isam]        & 0xFF;
					sbuf[sind+1] = ( sl[isam] >> 8 ) & 0xFF;
					sbuf[sind+2] =   sr[isam]        & 0xFF;
					sbuf[sind+3] = ( sr[isam] >> 8 ) & 0xFF;
					}
				break;
			case QUANT_32 :	// quantification sur 32 bandes et reconstruction
				/* filtrer en sous-bandes avec decimation */
				window_subband( sl, zbuf, 0 );
				filter_subband( zbuf, sbl );
				window_subband( sr, zbuf, 1 );
				filter_subband( zbuf, sbr );
	
				/* traiter les sous-bandes */
				sbprocess( sbl, sbr, kqu );
		
				/* reconstituer le signal */	   
				SubBandSynthesis ( sbl, 0, sl );
				SubBandSynthesis ( sbr, 1, sr );
				   
				/* ecrire les echantillons audio dans le buffer de trame */
				ibase = ichip * 128;
				for	( isam = 0; isam < 32; isam++ )
					{
					sind = ibase + ( 4 * isam );	   
					sbuf[sind]   =   sl[isam]        & 0xFF;
					sbuf[sind+1] = ( sl[isam] >> 8 ) & 0xFF;
					sbuf[sind+2] =   sr[isam]        & 0xFF;
					sbuf[sind+3] = ( sr[isam] >> 8 ) & 0xFF;
					}
				break;
			case STATS :	// statistiques par bandes
				/* filtrer en sous-bandes avec decimation */
				window_subband( sl, zbuf, 0 );
				filter_subband( zbuf, sbl );
				window_subband( sr, zbuf, 1 );
				filter_subband( zbuf, sbr );
				/* traiter les sous-bandes */
				sbstats( sbl, sbr, stats );
				break;
			}	
		}	// boucle des chips
	if	( ( d->hand >= 0 ) && ( ( option == QUANT_1 ) || ( option == QUANT_32 ) ) ) 
		{
		wrcont = write( d->hand, sbuf, rdcont );
		if ( wrcont < rdcont )
		   gasp("erreur ecriture disque (plein?)");
		}
	qbytes -= rdcont; ibloc++;
	}	// boucle des frames

if	( option == STATS )
	{
	qchip = (int)stats[0][4];
	printf("        frequ. centr.   moy L   moy R   max L   max R\n");
	for	( isam = 0; isam < 32; isam++ )
		printf("\t%7.1f\t\t%6.4f\t%6.4f\t%6.4f\t%6.4f\n",
			22050 * ((isam+0.5)/32.0), stats[isam][0] / qchip, stats[isam][1] / qchip,
			stats[isam][2], stats[isam][3] );
	}
}

static void usage()
{
fprintf( stderr, "Ce programme sert a evaluer le filtrage en 32 sous-bandes type MP3.\n\n");
fprintf( stderr, "\nUsage 1 : wsub source.wav dest.wav quantum_global\n");
fprintf( stderr, "--> quantification globale (sans filtrage)\n\n");
fprintf( stderr, "\nUsage 2 : wsub source.wav dest.wav\n");
fprintf( stderr, "--> quantification sur 32 sous-bandes type MP3.\n");
fprintf( stderr, "L'utilisateur doit fournir un fichier 'quant.txt'\n");
fprintf( stderr, "contenant un coefficient de sous-bande par ligne,\n");
fprintf( stderr, "soit 32 coeffs pour le canal 0 (L) et 32 pour le canal 1 (R)\n\n");
fprintf( stderr, "Si le fichier contient 32 coeffs ou moins, les deux canaux\n");
fprintf( stderr, "auront le meme filtrage.\n");
fprintf( stderr, "un coeff 0.0 ne quantifie pas, un coeff > 2.0 eteint la bande\n");
fprintf( stderr, "\nUsage 3 : wsub source.wav\n");
fprintf( stderr, "--> statistiques par bande : moyenne et max de la valeur absolue\n\n");
fprintf( stderr, "\n");
exit(1);
}

int main( int argc, char ** argv )
{
wavpars s, d;
char snam[256];
char dnam[256];
int option = 0;
double quantum_global = 0.0;

switch	( argc )
	{
	case 2 : option = STATS; break;
	case 3 : option = QUANT_32; break;
	case 4 : option = QUANT_1; break;
	default : usage();
	}

// ouverture fichier source
snprintf( snam, sizeof( snam ), "%s", argv[1] );
printf("ouverture %s en lecture\n", snam );
s.hand = open( snam, O_RDONLY | O_BINARY );
if ( s.hand == -1 ) gasp("%s introuvable", snam );
WAVreadHeader( &s );
if (
   ( s.chan != 2 )   ||
   ( s.resol != 16 )
   )
   gasp("programme seulement pour fichiers stereo 16 bits");

// ouverture fichier dest. si necessaire
if	( ( option == QUANT_1 ) || ( option == QUANT_32 ) )
	{
	d = s;
	snprintf( dnam, sizeof( dnam ), "%s", argv[2] );
	printf("ouverture %s en ecriture\n", dnam );
	d.hand = open( dnam, O_RDWR | O_BINARY | O_CREAT | O_TRUNC, 0666 );
	if ( d.hand == -1 ) gasp("pb ouverture %s pour ecrire", dnam );
	WAVwriteHeader( &d );
	}
else	{
	d.hand = -1;
	}

switch	( option )
	{
	case QUANT_1 : quantum_global = strtod( argv[3], NULL );
		printf("quantification globale, quantum_global = %g ...\n", quantum_global );
		break;
	case QUANT_32 :
		printf("quantification par bandes ...\n" );
		break;
	case STATS :
		printf("statistiques par bandes ... \n" );
		break;
	}

process_wav( &s, &d, option, quantum_global );

close( s.hand );
if	( d.hand >= 0 )
	close( d.hand );
return 0;
}

