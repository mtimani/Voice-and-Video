// compression 
int lzmac( char * in_nam, char * out_nam );
// decompression 
int lzmad( char * in_nam, char * out_nam );
