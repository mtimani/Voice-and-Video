void draw_vector( int x0, int y0, int x1, int y1, unsigned char * dest, int stride, int w, int h );
